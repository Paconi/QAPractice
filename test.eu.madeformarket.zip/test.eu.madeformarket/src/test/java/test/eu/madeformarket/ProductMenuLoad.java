package test.eu.madeformarket;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ProductMenuLoad extends BaseTest{

	@Test
	public void openProductPage() {
		driver.get("https://www.madeformarket.eu");
		MainMenu menu;
		
		try {
			Thread.sleep(2000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}

		String xpathButtonProducti = "//button[contains(text(),'ПРОДУКТИ')]";
		String xpathMainMenuItem = "//button[contains(text(),'Компютри')]";
		String xpathSubMenuItem = "//a[contains(text(),'All in One')]";
		String xpathproductPageHeader = "//h1[contains(text(),'Компютри \\ All in One')]";
		
		menu = new MainMenu(driver);
		menu.getProductPage(xpathButtonProducti, xpathMainMenuItem, xpathSubMenuItem);
		
		try {
			Thread.sleep(2000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		String header = menu.getProductHeader(xpathproductPageHeader);
		Assert.assertEquals(header, "Компютри \\ All in One");
	}
}
