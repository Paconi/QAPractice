package test.eu.madeformarket;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SuccessfullUserLogin extends BaseTest {

	@Test
	public void doLogin() {
		driver.get("https://www.madeformarket.eu//Account//Login");
		try {
			Thread.sleep(2000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}

		HomePage homePage = page.getInstance(LoginPage.class).doLogin("Niko", "12345Qwe!");
		String url =  homePage.driver.getCurrentUrl();
		String str = url.substring(url.length()-8);
		Assert.assertEquals(str, "CProfile");
	}
}
