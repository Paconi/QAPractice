package test.eu.madeformarket;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage extends BasePage{

	private By username = By.id("UserName");
    private By password = By.id("Password");
    private By loginButton = By.xpath("//body/div[@id='wrap']/div[@id='R_Body']/div[1]/div[1]/section[1]/form[1]/div[4]/div[1]/input[1]");
	
	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	public WebElement getUserName() {
	
		return getElement(username);
	}

	public WebElement getPassword() {
		
		return getElement(password);
	}

	public WebElement getLoginButton() {
		
		return getElement(loginButton);
	}

	public HomePage doLogin(String user, String pass) {
		getUserName().sendKeys(user);
		getPassword().sendKeys(pass);
		getLoginButton().click();
		
		return getInstance(HomePage.class);
	} 

}
