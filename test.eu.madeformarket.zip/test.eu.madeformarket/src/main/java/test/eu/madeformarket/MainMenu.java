package test.eu.madeformarket;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MainMenu extends BasePage {

	private By mainButton;
	private By mainMenuItem;
	private By subMenuItem;
	private By productHeader;
	
	public MainMenu(WebDriver driver) {
		super(driver);
	}

	public WebElement getMainButton(String xpath) {
		this.mainButton = By.xpath(xpath);
		return getElement(this.mainButton);
	}
	
	public WebElement getMainMenuItem(String xpath) {
		this.mainMenuItem = By.xpath(xpath);
		return getElement(this.mainMenuItem);
	}

	public WebElement getSubMenuItem(String xpath) {
		this.subMenuItem = By.xpath(xpath);
		return getElement(this.subMenuItem);
	}

	public String getProductHeader(String xpath) {
		this.productHeader = By.xpath(xpath);
		return getPageHeader(this.productHeader);
	}

	public void getProductPage(String xpathButton, String xpathMainMenu,String xpathSubMenu) {
		getMainButton(xpathButton).click();
		getMainMenuItem(xpathMainMenu).click();
		getSubMenuItem(xpathSubMenu).click();
	}
}
